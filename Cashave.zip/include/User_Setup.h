#define USER_SETUP_LOADED

#define ILI9341_DRIVER

#define TFT_WIDTH  240
#define TFT_HEIGHT 320

#define TFT_CS    2
#define TFT_DC    1
#define TFT_RST   14

#define TFT_MOSI  40
#define TFT_MISO  41
#define TFT_SCLK  42

#define SPI_FREQUENCY      27000000
#define SPI_READ_FREQUENCY 20000000

#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_FONT6
#define LOAD_FONT7
#define LOAD_FONT8
#define LOAD_GFXFF