#pragma once

#include <Arduino.h>
#include <math.h>

#define NUM_CLASSES 5
#define K_VALUE 3

const char* const CLASS_NAMES[NUM_CLASSES] = {
    "Rp 1.000",
    "Rp 2.000",
    "Rp 5.000",
    "Rp 10.000",
    "Rp 20.000"
};

struct Sample {
    float r;
    float g;
    float b;
    uint8_t label;
};

const Sample dataset[] = {

    // ================= Rp1000 =================
    {173,168,165,0},
    {164,163,166,0},
    {274,266,254,0},
    {239,242,242,0},
    {251,248,238,0},
    {165,163,167,0},
    {185,179,174,0},
    {243,215,215,0},
    {233,208,207,0},
    {231,209,212,0},
    {195,198,211,0},
    {197,201,217,0},
    {246,238,226,0},
    {246,221,220,0},
    {237,211,208,0},

    // ================= Rp2000 =================
    {258,246,220,1},
    {276,268,238,1},
    {249,241,214,1},
    {251,246,220,1},
    {242,224,196,1},
    {228,212,187,1},
    {230,216,192,1},
    {248,233,207,1},
    {180,171,153,1},
    {189,179,158,1},
    {186,176,157,1},
    {280,266,228,1},
    {286,263,222,1},
    {290,277,236,1},
    {276,272,235,1},

    // ================= Rp5000 =================
    {183,221,245,2},
    {213,240,253,2},
    {221,252,270,2},
    {198,226,247,2},
    {209,234,256,2},
    {212,219,241,2},
    {208,219,249,2},
    {200,214,231,2},
    {207,233,260,2},
    {242,274,301,2},
    {240,287,301,2},
    {202,220,246,2},
    {197,225,236,2},
    {215,241,248,2},
    {216,241,251,2},

    // ================= Rp10000 =================
    {246,306,276,3},
    {253,287,246,3},
    {236,258,222,3},
    {247,286,247,3},
    {195,188,162,3},
    {174,167,144,3},
    {212,202,170,3},
    {197,188,160,3},
    {191,189,167,3},
    {201,192,161,3},
    {199,191,161,3},
    {213,249,233,3},
    {253,293,265,3},
    {213,268,260,3},
    {216,246,227,3},

    // ================= Rp20000 =================
    {260,229,210,4},
    {252,226,208,4},
    {250,224,211,4},
    {245,220,205,4},
    {210,187,179,4},
    {224,200,194,4},
    {221,198,190,4},
    {219,192,186,4},
    {231,238,226,4},
    {257,277,254,4},
    {237,244,226,4},
    {167,154,140,4},
    {207,185,179,4},
    {212,189,183,4},
    {195,177,171,4}
};

const int TOTAL_SAMPLES =
    sizeof(dataset) / sizeof(dataset[0]);

struct Neighbor {
    float distance;
    uint8_t label;
};

float euclideanDistance(
    float r1,float g1,float b1,
    float r2,float g2,float b2)
{
    float dr=r1-r2;
    float dg=g1-g2;
    float db=b1-b2;

    return sqrtf(
        dr*dr +
        dg*dg +
        db*db);
}

int predictMoney(
    float r,
    float g,
    float b,
    float* confidence)
{
    Neighbor neighbors[TOTAL_SAMPLES];

    for(int i=0;i<TOTAL_SAMPLES;i++)
    {
        neighbors[i].distance =
            euclideanDistance(
                r,g,b,
                dataset[i].r,
                dataset[i].g,
                dataset[i].b);

        neighbors[i].label =
            dataset[i].label;
    }

    for(int i=0;i<TOTAL_SAMPLES-1;i++)
    {
        for(int j=i+1;j<TOTAL_SAMPLES;j++)
        {
            if(neighbors[j].distance <
               neighbors[i].distance)
            {
                Neighbor temp =
                    neighbors[i];

                neighbors[i] =
                    neighbors[j];

                neighbors[j] =
                    temp;
            }
        }
    }

    int votes[NUM_CLASSES]={0};

    for(int i=0;i<K_VALUE;i++)
    {
        votes[
            neighbors[i].label
        ]++;
    }

    int bestClass=0;
    int bestVotes=0;

    for(int i=0;i<NUM_CLASSES;i++)
    {
        if(votes[i]>bestVotes)
        {
            bestVotes=votes[i];
            bestClass=i;
        }
    }

    *confidence =
        (float)bestVotes /
        (float)K_VALUE;

    return bestClass;
}