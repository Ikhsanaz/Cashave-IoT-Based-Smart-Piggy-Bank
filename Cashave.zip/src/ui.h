#pragma once
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include "knn_data.h"

// ══════════════════════════════════════════════════════════════
//  ui.h  —  Fungsi tampilan LCD ILI9341 320×240 (Adafruit Edition)
// ══════════════════════════════════════════════════════════════

// ── Palet warna UI ──────────────────────────────────────────
#define COL_BG        0x0841   
#define COL_PANEL     0x10A3   
#define COL_ACCENT    0x07FF   
#define COL_WHITE     0xFFFF
#define COL_GRAY      0x7BEF
#define COL_DARKGRAY  0x39E7
#define COL_GREEN     0x07E0
#define COL_ORANGE    0xFD20
#define COL_RED       0xF800
#define COL_YELLOW    0xFFE0

#define RGB565(r,g,b) ((uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)))

// ── Dimensi layout ──────────────────────────────────────────
#define LCD_W    320
#define LCD_H    240
#define MARGIN   10

// ── Helper Fungsi Teks Center Alignment untuk Adafruit GFX ───
void drawStringCenter(Adafruit_ILI9341& tft, const char* text, int cx, int cy, uint8_t size) {
    tft.setTextSize(size);
    int16_t x1, y1;
    uint16_t w, h;
    tft.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);
    tft.setCursor(cx - (w / 2), cy - (h / 2));
    tft.print(text);
}

// ══════════════════════════════════════════════════════════════
//  drawHeader
// ══════════════════════════════════════════════════════════════
void drawHeader(Adafruit_ILI9341& tft) {
    tft.fillRect(0, 0, LCD_W, 36, COL_ACCENT);

    tft.setTextColor(COL_BG);
    drawStringCenter(tft, "PENDETEKSI UANG RUPIAH", LCD_W / 2, 12, 2);

    tft.setTextColor(0x0020);  
    drawStringCenter(tft, "ESP32-S3  |  TCS3200  |  KNN", LCD_W / 2, 26, 1);

    tft.drawFastHLine(0, 36, LCD_W, COL_BG);
}

// ══════════════════════════════════════════════════════════════
//  drawStatusBar
// ══════════════════════════════════════════════════════════════
void drawStatusBar(Adafruit_ILI9341& tft, const char* msg, uint16_t color) {
    tft.fillRect(0, 224, LCD_W, 16, COL_PANEL);
    tft.drawFastHLine(0, 224, LCD_W, COL_ACCENT);
    
    tft.setTextColor(color);
    tft.setTextSize(1);
    tft.setCursor(MARGIN, 228); // Dityesuaikan offset Y agar rapi
    tft.print(msg);
}

// ══════════════════════════════════════════════════════════════
//  drawSensorBox
// ══════════════════════════════════════════════════════════════
void drawSensorBox(Adafruit_ILI9341& tft, uint16_t r, uint16_t g, uint16_t b) {
    int x = MARGIN, y = 44, w = 140, h = 80;

    tft.fillRoundRect(x, y, w, h, 6, COL_PANEL);
    tft.drawRoundRect(x, y, w, h, 6, COL_DARKGRAY);

    tft.setTextColor(COL_GRAY);
    tft.setTextSize(1);
    tft.setCursor(x + 8, y + 6);
    tft.print("SENSOR RGB");
    tft.drawFastHLine(x + 8, y + 18, w - 16, COL_DARKGRAY);

    char buf[12];
    tft.setTextSize(1); // Ukuran font disesuaikan dengan skala Adafruit standard

    // Nilai R
    tft.setTextColor(0xF800);  
    tft.setCursor(x + 8, y + 26); tft.print("R: ");
    tft.setTextColor(COL_WHITE);
    sprintf(buf, "%4d", r); tft.print(buf);

    // Nilai G
    tft.setTextColor(0x07E0);  
    tft.setCursor(x + 8, y + 42); tft.print("G: ");
    tft.setTextColor(COL_WHITE);
    sprintf(buf, "%4d", g); tft.print(buf);

    // Nilai B
    tft.setTextColor(0x001F);  
    tft.setCursor(x + 8, y + 58); tft.print("B: ");
    tft.setTextColor(COL_WHITE);
    sprintf(buf, "%4d", b); tft.print(buf);

    // Preview warna kecil
    uint8_t rn = (uint8_t)min((int)r, 255);
    uint8_t gn = (uint8_t)min((int)g, 255);
    uint8_t bn = (uint8_t)min((int)b, 255);
    tft.fillRect(x + w - 28, y + 22, 20, 48, RGB565(rn, gn, bn));
    tft.drawRect(x + w - 29, y + 21, 22, 50, COL_GRAY);
}

// ══════════════════════════════════════════════════════════════
//  drawConfidenceBox
// ══════════════════════════════════════════════════════════════
void drawConfidenceBox(Adafruit_ILI9341& tft, float confidence) {
    int x = 164, y = 44, w = 146, h = 80;

    tft.fillRoundRect(x, y, w, h, 6, COL_PANEL);
    tft.drawRoundRect(x, y, w, h, 6, COL_DARKGRAY);

    tft.setTextColor(COL_GRAY);
    tft.setTextSize(1);
    tft.setCursor(x + 8, y + 6);
    tft.print("KEPERCAYAAN");
    tft.drawFastHLine(x + 8, y + 18, w - 16, COL_DARKGRAY);

    // Persentase besar
    int pct = (int)(confidence * 100);
    uint16_t textColor = (pct >= 80) ? COL_GREEN : (pct >= 60) ? COL_YELLOW : COL_ORANGE;
    char buf[8];
    sprintf(buf, "%d%%", pct);
    tft.setTextColor(textColor);
    drawStringCenter(tft, buf, x + w / 2, y + 38, 3); // Ukuran 3 disesuaikan untuk Adafruit

    // Bar horizontal
    int bx = x + 8, by = y + 58, bw = w - 16, bh = 10;
    tft.fillRoundRect(bx, by, bw, bh, 3, COL_DARKGRAY);
    int fill = (int)((float)bw * confidence);
    if (fill > 0)
        tft.fillRoundRect(bx, by, fill, bh, 3, textColor);

    // Label status
    const char* label = (pct >= 80) ? "Sangat Yakin" : (pct >= 60) ? "Cukup Yakin" : "Kurang Yakin";
    tft.setTextColor(COL_GRAY);
    drawStringCenter(tft, label, x + w / 2, y + 72, 1);
}

// ══════════════════════════════════════════════════════════════
//  drawResultCard
// ══════════════════════════════════════════════════════════════
void drawResultCard(Adafruit_ILI9341& tft, int classIdx, float confidence) {
    int x = MARGIN, y = 134, w = LCD_W - 2 * MARGIN, h = 84;

    tft.fillRoundRect(x, y, w, h, 8, COL_PANEL);

    if (classIdx < 0 || confidence < 0.6f) {
        tft.drawRoundRect(x, y, w, h, 8, COL_ORANGE);
        tft.setTextColor(COL_ORANGE);
        drawStringCenter(tft, "TIDAK DIKENALI", LCD_W / 2, y + 22, 2);
        tft.setTextColor(COL_GRAY);
        drawStringCenter(tft, "Posisikan uang lebih dekat", LCD_W / 2, y + 48, 1);
        drawStringCenter(tft, "ke sensor, lalu scan ulang", LCD_W / 2, y + 62, 1);
        return;
    }

    uint8_t cr = CLASS_COLORS[classIdx][0];
    uint8_t cg = CLASS_COLORS[classIdx][1];
    uint8_t cb = CLASS_COLORS[classIdx][2];
    uint16_t accent = RGB565(cr, cg, cb);

    tft.drawRoundRect(x, y, w, h, 8, accent);
    tft.drawRoundRect(x+1, y+1, w-2, h-2, 7, accent);
    tft.fillRoundRect(x, y, 6, h, 4, accent);

    // Label "TERDETEKSI"
    tft.setTextColor(accent);
    tft.setTextSize(1);
    tft.setCursor(x + 16, y + 10);
    tft.print("TERDETEKSI");

    // Nama denominasi (besar)
    tft.setTextColor(COL_WHITE);
    tft.setTextSize(3);
    tft.setCursor(x + 16, y + 24);
    tft.print(CLASS_NAMES[classIdx]);

    // Swatch warna kecil di kanan
    tft.fillRoundRect(x + w - 40, y + 16, 28, 52, 4, accent);
    tft.drawRoundRect(x + w - 41, y + 15, 30, 54, 4, COL_GRAY);

    // Simbol mata uang "Rp" di dalam swatch
    tft.setTextColor(COL_BG);
    drawStringCenter(tft, "Rp", x + w - 26, y + 42, 1);

    tft.drawFastHLine(x + 16, y + 60, w - 60, COL_DARKGRAY);

    // Teks "scan berikutnya"
    tft.setTextColor(COL_GRAY);
    tft.setTextSize(1);
    tft.setCursor(x + 16, y + 68);
    tft.print("Tekan tombol untuk scan ulang");
}

// ══════════════════════════════════════════════════════════════
//  drawWaitScreen
// ══════════════════════════════════════════════════════════════
void drawWaitScreen(Adafruit_ILI9341& tft) {
    tft.fillRect(0, 37, LCD_W, LCD_H - 37 - 16, COL_BG);

    int cx = LCD_W / 2, cy = 130;
    tft.drawCircle(cx, cy, 38, COL_DARKGRAY);
    tft.drawCircle(cx, cy, 36, COL_PANEL);
    tft.fillCircle(cx, cy, 34, COL_PANEL);

    tft.setTextColor(COL_ACCENT);
    drawStringCenter(tft, ">>", cx, cy, 3);

    tft.setTextColor(COL_WHITE);
    drawStringCenter(tft, "Tempelkan Uang", LCD_W / 2, cy + 52, 2);
    tft.setTextColor(COL_GRAY);
    drawStringCenter(tft, "ke sensor TCS3200", LCD_W / 2, cy + 74, 1);
    drawStringCenter(tft, "lalu tekan tombol SCAN", LCD_W / 2, cy + 88, 1);

    drawStatusBar(tft, "Siap mendeteksi...", COL_ACCENT);
}

// ══════════════════════════════════════════════════════════════
//  drawScanningScreen
// ══════════════════════════════════════════════════════════════
void drawScanningScreen(Adafruit_ILI9341& tft) {
    tft.fillRect(0, 37, LCD_W, LCD_H - 37 - 16, COL_BG);

    int cx = LCD_W / 2, cy = 120;
    tft.drawCircle(cx, cy, 40, COL_ACCENT);
    tft.fillCircle(cx, cy, 37, COL_PANEL);

    tft.setTextColor(COL_ACCENT);
    drawStringCenter(tft, "...", cx, cy - 4, 3);

    tft.setTextColor(COL_WHITE);
    drawStringCenter(tft, "Membaca Sensor", LCD_W / 2, cy + 56, 2);
    tft.setTextColor(COL_GRAY);
    drawStringCenter(tft, "Harap tunggu...", LCD_W / 2, cy + 76, 1);

    drawStatusBar(tft, "Sedang memproses...", COL_YELLOW);
}

// ══════════════════════════════════════════════════════════════
//  drawFullResult
// ══════════════════════════════════════════════════════════════
void drawFullResult(Adafruit_ILI9341& tft, uint16_t r, uint16_t g, uint16_t b,
                    int classIdx, float confidence) {
    tft.fillRect(0, 37, LCD_W, LCD_H - 37 - 16, COL_BG);
    drawSensorBox(tft, r, g, b);
    drawConfidenceBox(tft, confidence);
    drawResultCard(tft, classIdx, confidence);

    const char* statusMsg = (confidence >= 0.8f) ? "Deteksi berhasil!" :
                            (confidence >= 0.6f) ? "Terdeteksi (cukup yakin)" :
                                                   "Tidak yakin - coba ulang";
    uint16_t statusCol = (confidence >= 0.8f) ? COL_GREEN :
                         (confidence >= 0.6f) ? COL_YELLOW : COL_ORANGE;
    drawStatusBar(tft, statusMsg, statusCol);
}

// ══════════════════════════════════════════════════════════════
//  drawBootScreen
// ══════════════════════════════════════════════════════════════
void drawBootScreen(Adafruit_ILI9341& tft) {
    tft.fillScreen(COL_BG);

    tft.setTextColor(COL_ACCENT);
    drawStringCenter(tft, "DETEKTOR", LCD_W / 2, 70, 3);
    drawStringCenter(tft, "UANG RUPIAH", LCD_W / 2, 106, 3);

    tft.setTextColor(COL_GRAY);
    drawStringCenter(tft, "ESP32-S3  +  TCS3200  +  ILI9341", LCD_W / 2, 140, 1);

    tft.drawRoundRect(40, 165, 240, 14, 5, COL_DARKGRAY);
    for (int i = 0; i <= 240; i += 8) {
        tft.fillRoundRect(40, 165, i, 14, 5, COL_ACCENT);
        delay(15);
    }

    tft.setTextColor(COL_WHITE);
    drawStringCenter(tft, "Sistem Siap", LCD_W / 2, 195, 2);
    delay(600);
}