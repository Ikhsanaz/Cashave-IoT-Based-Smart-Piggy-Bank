// ============================================================
//  User_Setup.h  —  Konfigurasi TFT_eSPI
//  Driver : ILI9341
//  MCU    : ESP32-S3
//  File ini HARUS ada di folder include/ proyek PlatformIO
//  dan platformio.ini harus mengandung:
//      build_flags = -D USER_SETUP_LOADED=1
//                    -I include
// ============================================================

#define USER_SETUP_LOADED   // Wajib — mencegah TFT_eSPI load User_Setup.h bawaan

// ── Driver LCD ───────────────────────────────────────────────
#define ILI9341_DRIVER

// ── Pin SPI untuk ILI9341 ────────────────────────────────────
#define TFT_CS    2
#define TFT_DC    1
#define TFT_RST   14
#define TFT_MOSI  40
#define TFT_MISO  41
#define TFT_SCLK  42

// ── Gunakan SPI hardware ESP32-S3 ────────────────────────────
// Tidak perlu define VSPI/HSPI — TFT_eSPI otomatis pilih
// berdasarkan pin yang didefinisikan di atas.

// ── Frekuensi SPI ────────────────────────────────────────────
// Mulai dari 27MHz dulu. Jika stabil, naikkan ke 40MHz.
#define SPI_FREQUENCY       27000000
#define SPI_READ_FREQUENCY  20000000

// ── Font yang dimuat ─────────────────────────────────────────
#define LOAD_GLCD    // Font 1 (Adafruit GFX default, 6x8px)
#define LOAD_FONT2   // Font 2 (7seg style, 16px)
#define LOAD_FONT4   // Font 4 (26px)
#define LOAD_FONT6   // Font 6 (48px angka saja)
#define LOAD_FONT7   // Font 7 (7seg 48px)
#define LOAD_FONT8   // Font 8 (75px angka saja)
#define LOAD_GFXFF   // FreeFonts (Adafruit GFX compatible)
#define SMOOTH_FONT  // Anti-aliased font (butuh SPIFFS/LittleFS jika dipakai)
