#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <FirebaseESP32.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>

#define WIFI_SSID        "iksan"
#define WIFI_PASSWORD    "09876543"
#define FIREBASE_HOST    "https://cashave-default-rtdb.firebaseio.com/" 
#define FIREBASE_AUTH    "l0yZRNCEfopb01nkiG0T5yvQclPe70widJXSXksW"

#define PIN_IR          14 
#define TFT_CS          2   
#define TFT_DC          1   
#define TFT_RST         3   
#define TFT_MOSI        47  
#define TFT_MISO        48  
#define TFT_SCLK        45  

#define S0              19  
#define S1              20  
#define S2              21  
#define S3              4  
#define OUT_PIN         5   
#define PIN_LED_SENSOR  6   
#define COLOR_BG        0x0000 
#define COLOR_CARD      0x18C3 
#define COLOR_TEXT_MINT 0x67EC 
#define COLOR_TEXT_SUB  0x9CE7 
#define COLOR_BORDER    0x31A6 
#define COLOR_BAR_BG    0x2104 

Adafruit_ILI9341 tft(TFT_CS, TFT_DC, TFT_RST);

// FreRTOS Handle untuk Queue (Antrean Data Nominal Uang)
QueueHandle_t msgQueue;

// Variabel Kontrol Sistem (Menggunakan volatile/Mutex jika diakses multi-tasking, 
// namun di sini dilindungi oleh alur sekuensial task cloud)
unsigned long totalSaldo = 0; 
unsigned long totalHargaTarget = 0; 
int jumlahItemTarget = 0;           

struct Sample { int r; int g; int b; int nominal; };
Sample trainingData[] = {
    {173,168,165,1000},
    {164,163,166,1000},
    {274,266,254,1000},
    {239,242,242,1000},
    {251,248,238,1000},
    {165,163,167,1000},
    {185,179,174,1000},
    {243,215,215,1000},
    {233,208,207,1000},
    {231,209,212,1000},
    {195,198,211,1000},
    {197,201,217,1000},
    {246,238,226,1000},
    {246,221,220,1000},
    {237,211,208,1000},
    {154,155,159,1000},
{143,145,151,1000},
{137,141,152,1000},
{154,172,173,1000},
{166,183,180,1000},

{172,170,158,1000},
{173,171,159,1000},
{179,177,165,1000},
{181,179,168,1000},
{176,174,161,1000},
{209,212,229,1000},
{206,208,222,1000},
{222,225,243,1000},
{221,223,240,1000},

{212,205,203,1000},
{193,189,190,1000},
{278,279,273,1000},


    {258,246,220,2000},
    {276,268,238,2000},
    {249,241,214,2000},
    {251,246,220,2000},
    {242,224,196,2000},
    {228,212,187,2000},
    {230,216,192,2000},
    {248,233,207,2000},
    {180,171,153,2000},
    {189,179,158,2000},
    {186,176,157,2000},
    {280,266,228,2000},
    {286,263,222,2000},
    {290,277,236,2000},
    {276,272,235,2000},
    {137,142,164,2000},
{124,131,155,2000},
{142,144,167,2000},
{123,125,145,2000},
{143,150,168,2000},

{191,202,225,2000},
{194,206,232,2000},
{187,197,224,2000},
{186,196,221,2000},
{192,203,229,2000},

{209,197,175,2000},
{205,194,172,2000},
{323,314,278,2000},
{320,313,280,2000},
{307,297,261,2000},
{272,252,223,2000},

{216,203,184,2000},//


    {183,221,245,5000},
    {213,240,253,5000},
    {221,252,270,5000},
    {198,226,247,5000},
    {209,234,256,5000},
    {212,219,241,5000},
    {208,219,249,5000},
    {200,214,231,5000},
    {207,233,260,5000},
    {242,274,301,5000},
    {240,287,301,5000},
    {202,220,246,5000},
    {197,225,236,5000},
    {215,241,248,5000},
    {216,241,251,5000},
    {213,180,164,5000},
{179,153,143,5000},
{195,172,165,5000},
{179,159,141,5000},
{190,167,160,5000},
{268,300,327,5000},//

    {246,306,276,10000},
    {253,287,246,10000},
    {236,258,222,10000},
    {247,286,247,10000},
    {195,188,162,10000},
    {174,167,144,10000},
    {212,202,170,10000},
    {197,188,160,10000},
    {191,189,167,10000},
    {201,192,161,10000},
    {199,191,161,10000},
    {213,249,233,10000},
    {253,293,265,10000},
    {213,268,260,10000},
    {216,246,227,10000},
    {194,204,235,10000},
{195,204,240,10000},
{195,203,237,10000},
{179,154,167,10000},
{150,127,142,10000},
{227,215,181,10000},

{159,129,133,10000},
{152,128,138,10000},
{151,130,142,10000},
{185,194,230,10000},
{200,204,235,10000},
{182,190,222,10000},

{239,226,192,10000},
{230,220,188,10000},
{280,317,264,10000},
{265,298,263,10000},
{281,321,296,10000},

{259,299,282,10000},

{243,232,197,10000},//
{246,235,201,10000},//
{250,237,201,10000},//

{200,195,170,10000},///
{264,298,278,10000},///



    {260,229,210,20000},
    {252,226,208,20000},
    {250,224,211,20000},
    {245,220,205,20000},
    {210,187,179,20000},
    {224,200,194,20000},
    {221,198,190,20000},
    {219,192,186,20000},
    {231,238,226,20000},
    {257,277,254,20000},
    {237,244,226,20000},
    {167,154,140,20000},
    {207,185,179,20000},
    {212,189,183,20000},
    {195,177,171,20000},
    {166,160,171,20000},
{170,160,169,20000},
{174,159,168,20000},
{167,163,176,20000},
{156,150,160,20000},

{140,158,171,20000},
{129,147,160,20000},
{132,150,161,20000},
{156,177,183,20000},
{169,190,198,20000},
{154,177,182,20000},
{147,138,150,20000},

{234,208,203,20000},
{188,172,160,20000},
{244,249,231,20000},
{226,253,238,20000},
{233,262,246,20000},
{252,259,242,20000},
{267,295,274,20000},
{317,271,247,20000},
{281,248,228,20000},
{293,258,235,20000},

{263,233,226,20000},
{270,277,257,20000},
{256,287,269,20000},
{239,213,202,20000},
{268,238,228,20000},

{296,311,288,20000},//
{296,311,288,20000},//
{325,287,271,20000},//


{151,146,156,20000}
};

const int DATA_SIZE = sizeof(trainingData) / sizeof(trainingData[0]);

struct Neighbor { float distance; int nominal; };

float distanceRGB(int r1, int g1, int b1, int r2, int g2, int b2) {
    return sqrt(pow(r1-r2,2) + pow(g1-g2,2) + pow(b1-b2,2));
}

int classifyKNN(int r, int g, int b) {
    Neighbor neighbors[DATA_SIZE];
    for(int i=0; i<DATA_SIZE; i++) {
        neighbors[i].distance = distanceRGB(r, g, b, trainingData[i].r, trainingData[i].g, trainingData[i].b);
        neighbors[i].nominal = trainingData[i].nominal;
    }
    for(int i=0; i<DATA_SIZE-1; i++) {
        for(int j=i+1; j<DATA_SIZE; j++) {
            if(neighbors[j].distance < neighbors[i].distance) {
                Neighbor temp = neighbors[i];
                neighbors[i] = neighbors[j];
                neighbors[j] = temp;
            }
        }
    }
    return neighbors[0].nominal;
}

void setupColorSensor() {
    pinMode(S0, OUTPUT); pinMode(S1, OUTPUT);
    pinMode(S2, OUTPUT); pinMode(S3, OUTPUT);
    pinMode(OUT_PIN, INPUT);
    digitalWrite(S0, HIGH); digitalWrite(S1, LOW);
}

int readFrequency(bool s2, bool s3) {
    digitalWrite(S2, s2); digitalWrite(S3, s3);
    vTaskDelay(20 / portTICK_PERIOD_MS); // Menggunakan RTOS Delay agar CPU tidak blocked
    return pulseIn(OUT_PIN, LOW, 50000);
}

void readRGB(int &r, int &g, int &b) {
    r = readFrequency(LOW, LOW);
    g = readFrequency(HIGH, HIGH);
    b = readFrequency(LOW, HIGH);
}

void hitungTotalTargetDariFirebase(FirebaseData &fbData) {
    if (WiFi.status() != WL_CONNECTED) return;
    if (Firebase.getJSON(fbData, "/targets")) {
        if (fbData.dataType() == "json") {
            FirebaseJson &json = fbData.jsonObject();
            FirebaseJsonData jsonData;
            totalHargaTarget = 0;
            jumlahItemTarget = 0;
            size_t totalKeys = json.iteratorBegin();
            String keyId, valueObject;
            int type = 0;
            for (size_t i = 0; i < totalKeys; i++) {
                json.iteratorGet(i, type, keyId, valueObject);
                if (json.get(jsonData, keyId + "/harga")) {
                    totalHargaTarget += jsonData.intValue;
                    jumlahItemTarget++;
                }
            }
            json.iteratorEnd(); 
        }
    }
}

void drawModernProgressBar(int x, int y, int width, int height, int radius, int percentage, uint16_t color) {
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;
    tft.fillRoundRect(x, y, width, height, radius, COLOR_BAR_BG);
    tft.drawRoundRect(x, y, width, height, radius, COLOR_BORDER);
    int progressWidth = (percentage * (width - 4)) / 100;
    if (progressWidth > 4) {
        tft.fillRoundRect(x + 2, y + 2, progressWidth, height - 4, radius - 1, color);
    } else if (progressWidth > 0) {
        tft.fillRect(x + 2, y + 2, progressWidth, height - 4, color);
    }
}

void showIdle() {
    tft.fillScreen(COLOR_BG);
    tft.fillRect(0, 0, 320, 40, COLOR_CARD);
    tft.drawFastHLine(0, 40, 320, COLOR_BORDER);
    tft.setTextColor(ILI9341_WHITE);   tft.setTextSize(2); tft.setCursor(15, 12);  tft.print("CASHAVE");
    tft.fillRoundRect(10, 52, 300, 65, 6, COLOR_CARD);
    tft.drawRoundRect(10, 52, 300, 65, 6, COLOR_BORDER);
    tft.setTextColor(COLOR_TEXT_SUB);  tft.setTextSize(1); tft.setCursor(22, 64);  tft.print("TOTAL BALANCE");
    tft.setTextColor(ILI9341_WHITE);   tft.setTextSize(3); tft.setCursor(22, 82);  tft.printf("Rp %d", totalSaldo);
    tft.fillRoundRect(10, 127, 300, 95, 6, COLOR_CARD);
    tft.drawRoundRect(10, 127, 300, 95, 6, COLOR_BORDER);
    tft.setTextColor(COLOR_TEXT_SUB);  tft.setTextSize(1); tft.setCursor(22, 138); tft.print("SAVING GOAL PROGRESS");
    tft.setTextColor(ILI9341_WHITE);   tft.setTextSize(1); tft.setCursor(22, 156);
    if (jumlahItemTarget > 0) tft.printf("Targets : %d Items", jumlahItemTarget);
    else tft.print("Targets : No active target");
    tft.setCursor(22, 170); tft.printf("Goal    : Rp %d", totalHargaTarget);
    int persenPencapaian = 0;
    if (totalHargaTarget > 0) {
        persenPencapaian = (totalSaldo * 100) / totalHargaTarget;
        if (persenPencapaian > 100) persenPencapaian = 100; 
    }
    tft.setTextColor(COLOR_TEXT_MINT); tft.setTextSize(1); tft.setCursor(260, 138); tft.printf("%d%%", persenPencapaian);
    uint16_t barColor = (persenPencapaian >= 100) ? ILI9341_GREEN : ILI9341_CYAN;
    drawModernProgressBar(22, 190, 276, 16, 4, persenPencapaian, barColor);
}

void showResult(int r, int g, int b, int nominal) {
    tft.fillScreen(COLOR_BG);
    tft.fillRoundRect(15, 15, 290, 210, 8, COLOR_CARD);
    tft.drawRoundRect(15, 15, 290, 210, 8, COLOR_BORDER);
    tft.setTextColor(ILI9341_WHITE);   tft.setTextSize(2); tft.setCursor(35, 30);  tft.println("MONEY DETECTED");
    tft.drawFastHLine(25, 52, 270, COLOR_BORDER);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_RED);     tft.setCursor(40, 70);  tft.printf("Sensor R : %d", r);
    tft.setTextColor(ILI9341_GREEN);   tft.setCursor(40, 88);  tft.printf("Sensor G : %d", g);
    tft.setTextColor(COLOR_TEXT_MINT); tft.setCursor(40, 106); tft.printf("Sensor B : %d", b);
    tft.drawFastHLine(35, 130, 250, COLOR_BORDER);
    tft.setTextColor(COLOR_TEXT_SUB);  tft.setTextSize(1); tft.setCursor(40, 145); tft.println("NOMINAL VALUE:");
    tft.setTextSize(4); tft.setCursor(40, 168);
    switch(nominal) {
        case 1000:  tft.setTextColor(ILI9341_WHITE);   tft.print("Rp 1K");   break;
        case 2000:  tft.setTextColor(ILI9341_YELLOW);  tft.print("Rp 2K");   break;
        case 5000:  tft.setTextColor(ILI9341_ORANGE);  tft.print("Rp 5K");   break;
        case 10000: tft.setTextColor(ILI9341_MAGENTA); tft.print("Rp 10K");  break;
        case 20000: tft.setTextColor(ILI9341_GREEN);   tft.print("Rp 20K");  break;
        default:    tft.setTextColor(ILI9341_RED);     tft.print("ERR!!");   break;
    }
}

// ── TASK 1: PEMINDAI SENSOR (DITEMPATKAN DI CORE 1) ─────────────────────────────────────────
void TaskSensing(void *pvParameters) {
    (void) pvParameters;
    for (;;) {
        if(digitalRead(PIN_IR) == LOW) {
            digitalWrite(PIN_LED_SENSOR, HIGH);
            vTaskDelay(300 / portTICK_PERIOD_MS);

            long Rsum = 0, Gsum = 0, Bsum = 0;
            for(int i=0; i<10; i++) {
                int r,g,b;
                readRGB(r,g,b);
                Rsum += r; Gsum += g; Bsum += b;
                vTaskDelay(20 / portTICK_PERIOD_MS);
            }

            int r = Rsum / 10; int g = Gsum / 10; int b = Bsum / 10;
            int nominal = classifyKNN(r, g, b);
            
            if (nominal == 1000 || nominal == 2000 || nominal == 5000 || nominal == 10000 || nominal == 20000) {
                totalSaldo += nominal; 
                showResult(r, g, b, nominal);

                tft.fillRoundRect(25, 195, 270, 24, 4, COLOR_BAR_BG);
                tft.drawRoundRect(25, 195, 270, 24, 4, ILI9341_ORANGE);
                tft.setTextSize(1); tft.setTextColor(ILI9341_ORANGE); tft.setCursor(40, 203); tft.print("Processing Sync...");

                xQueueSend(msgQueue, &nominal, portMAX_DELAY);
            } else {
                showResult(r, g, b, nominal); 
            }

            while(digitalRead(PIN_IR) == LOW) {
                vTaskDelay(10 / portTICK_PERIOD_MS);
            }
            digitalWrite(PIN_LED_SENSOR, LOW);
            vTaskDelay(1500 / portTICK_PERIOD_MS);
            showIdle(); 
        }
        vTaskDelay(50 / portTICK_PERIOD_MS); 
    }
}

// ── TASK 2: PENGURUS DATA INTERNET & FIREBASE (DITEMPATKAN DI CORE 0) ───────────────────────
void TaskFirebase(void *pvParameters) {
    (void) pvParameters;
    
    // Instansiasi object khusus untuk core ini agar aman dari Data Corruption
    FirebaseData fbData;
    FirebaseConfig fbConfig; 
    FirebaseAuth fbAuth;     

    fbConfig.host = FIREBASE_HOST;
    fbConfig.signer.tokens.legacy_token = FIREBASE_AUTH;
    Firebase.begin(&fbConfig, &fbAuth);
    Firebase.reconnectWiFi(true);

    // Ambil saldo awal
    if (Firebase.getInt(fbData, "/cashave/saldo")) totalSaldo = fbData.intData();
    hitungTotalTargetDariFirebase(fbData);
    showIdle(); // Trigger tampilan awal setelah data siap

    int receivedNominal = 0;
    for (;;) {
        // Task ini akan membeku/diam sampai ada kiriman data dari TaskSensing
        if (xQueueReceive(msgQueue, &receivedNominal, portMAX_DELAY) == pdPASS) {
            if (WiFi.status() == WL_CONNECTED) {
                Firebase.setInt(fbData, "/cashave/saldo", totalSaldo);
                hitungTotalTargetDariFirebase(fbData);
                
                // Perbarui banner di layar menjadi berhasil
                tft.fillRoundRect(25, 195, 270, 24, 4, COLOR_BAR_BG);
                tft.drawRoundRect(25, 195, 270, 24, 4, ILI9341_GREEN);
                tft.setTextColor(ILI9341_GREEN); tft.setCursor(40, 203);
                tft.print("Firebase Sync Success!");
            }
        }
    }
}

void setup() {
    Serial.begin(115200);
    SPI.begin(TFT_SCLK, TFT_MISO, TFT_MOSI);

    pinMode(PIN_IR, INPUT);
    pinMode(PIN_LED_SENSOR, OUTPUT);
    digitalWrite(PIN_LED_SENSOR, LOW);
    setupColorSensor();

    tft.begin();
    tft.setRotation(1);
    tft.fillScreen(COLOR_BG);
    tft.setTextColor(ILI9341_WHITE);   tft.setTextSize(2); tft.setCursor(20, 80);   tft.print("CASHAVE");
    tft.setTextColor(COLOR_TEXT_SUB);  tft.setTextSize(1); tft.setCursor(20, 105);  tft.print("Connecting network...");

    WiFi.mode(WIFI_STA);
    WiFi.disconnect(true); 
    delay(1000);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    esp_wifi_set_max_tx_power(52); 

    while (WiFi.status() != WL_CONNECTED) {
        delay(400);
        Serial.print(".");
    }
    Serial.println("\nWiFi Connected!");

    // 1. Buat RTOS Queue dengan kapasitas maksimal 5 antrean data (kapasitas tipe int)
    msgQueue = xQueueCreate(5, sizeof(int));

    if (msgQueue != NULL) {
        // 2. Daftarkan Task Firebase di CORE 0 (Core protokol jaringan)
        xTaskCreatePinnedToCore(TaskFirebase, "TaskFirebase", 8192, NULL, 2, NULL, 0);
        
        // 3. Daftarkan Task Sensing di CORE 1 (Core aplikasi hardware)
        xTaskCreatePinnedToCore(TaskSensing, "TaskSensing", 4096, NULL, 3, NULL, 1);
    }
}

void loop() {}